# MicrosipRentas

Aplicación de escritorio de WPF
