﻿using FirebirdSql.Data.FirebirdClient;
using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;

namespace Microsip_Rentas.ViewModel
{
    public class RentalContractVM : ViewModelBase, INotifyPropertyChanged
    {

        private ICommand _deleteCommand;
        private RentalContractRepository _repository;
        private RentalContract? _rentalContractEntity = null;
        public ObservableCollection<RentalContractRecord> RentalContractRecords { get; set; }
        public RentalContractRecord RentalContractRecord { get; set; }
        public ObservableCollection<RentalContract>RentalContracts { get; set;}
        // Comando para manejar la eliminación de registros
        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new RelayCommand(param => Delete((int)param), null);
                }

                return _deleteCommand;
            }
        }


        public RentalContractVM()
        {
            _rentalContractEntity = new RentalContract();
            _repository = new RentalContractRepository();
            RentalContractRecord = new RentalContractRecord();
            RentalContractRecords = new ObservableCollection<RentalContractRecord>();
            // Llenar con datos o hacer alguna lógica
            RentalContracts = new ObservableCollection<RentalContract>();
            GetAll(); // Llamamos al método para obtener los contratos cuando se crea la instancia del ViewModel
        }

        // Método para eliminar un contrato de renta
        public void Delete(int id)
        {
            if (MessageBox.Show("¿Desea eliminar este contrato de renta?", "RentalContract", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    // Llamamos al repositorio para eliminar el contrato de la base de datos
                    _repository.Delete(id);
                    MessageBox.Show("Contrato de renta eliminado correctamente.");

                    // Actualizamos la lista de contratos
                    GetAll();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error durante el proceso. " + ex.InnerException);
                }
            }
        }

        // Obtener todos los registros de contratos de renta
        public void GetAll()
        {
            // Limpiamos la colección antes de agregar los nuevos registros
            RentalContractRecords.Clear();

            try
            {
                // Obtenemos todos los contratos de la base de datos
                var contracts = _repository.GetAll();

                // Iteramos sobre los contratos y los agregamos a la ObservableCollection
                foreach (var contract in contracts)
                {
                    RentalContractRecords.Add(new RentalContractRecord
                    {
                        Id = contract.Id,
                        CustomerId = contract.CustomerId,
                        RentalDate = contract.RentalDate,
                        DueDate = contract.DueDate,
                        ReturnDate = contract.ReturnDate,
                       // RentalName = _repository.Get(contract.RentalStatusId).StatusName,
                        RentalPeriodId = contract.RentalPeriodId
                        // Aquí puedes agregar otras propiedades de RentalContract si es necesario
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al obtener los contratos. " + ex.Message);
            }
        }
    }
}


