﻿using FirebirdSql.Data.FirebirdClient;
using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;

namespace Microsip_Rentas.ViewModel
{
    public class AssetTypesVM : ViewModelBase, INotifyPropertyChanged
    {
        private ICommand _deleteCommand;
        private AssetTypeRepository _repository;
        private AssetType? _assetTypeEntity = null;
        public AssetTypeRecord AssetTypeRecord { get; set; }
        public ICommand DeleteCommand
        {
            get
            {
                //Trace.WriteLine("Entró al command");
                if (_deleteCommand == null)
                {
                    _deleteCommand = new RelayCommand(param => Delete((int)param), null);
                }

                return _deleteCommand;
            }
        }
        public AssetTypesVM()
        {
            _assetTypeEntity = new AssetType();
            _repository = new AssetTypeRepository();
            AssetTypeRecord = new AssetTypeRecord();

            GetAll();
        }


        //Manejo de eliminar
        public void Delete(int id)
        {
            // Mostrar el mensaje de confirmación para eliminar
            if (MessageBox.Show("¿Desea eliminar este tipo de activo?", "AssetType", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    var associatedAssets = _repository.Get(id); 
                    _repository.Delete(id);
                    MessageBox.Show("Tipo de activo eliminado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error durante el proceso. " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    GetAll();
                }
            }
        }



        //Obtenemos todos los registros de nuestra tabla
        public void GetAll()
        {
            AssetTypeRecord.AssetTypeRecords = new System.Collections.ObjectModel.ObservableCollection<AssetTypeRecord>();
            //Obtienes todos los registros de la tabla, conectandote al repositorio
            //Foreach de cada registro de mi tabla
            //Agregamos un nuevo objeto al records cada vez que recorremos el foreach
            _repository.GetAll().ForEach(data => AssetTypeRecord.AssetTypeRecords.Add(new AssetTypeRecord()
            {
                Id = data.Id,
                Name = data.Name,
                Description = data.Description,
                AbreviationName = data.AbreviationName,
                Price = data.Price,
            }));
        }
    }  
}
