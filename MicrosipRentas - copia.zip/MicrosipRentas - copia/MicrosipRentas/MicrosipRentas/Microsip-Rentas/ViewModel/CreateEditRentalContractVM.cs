﻿using FirebirdSql.Data.FirebirdClient;
using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using Microsip_Rentas.View;
using Microsoft.EntityFrameworkCore;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;

namespace Microsip_Rentas.ViewModel
{
    public class CreateEditRentalContractVM : ViewModelBase
    {
        // Comandos para guardar, reiniciar y editar contratos
        private ICommand _saveCommand;
        private ICommand _resetCommand;
        private ICommand _editCommand;


        // Repositorios para manejar datos de alquiler y períodos de renta
        private RentalPeriodRepository _rentalPeriodRepository;
        private RentalContractRepository _repository;
        private RentalStatusRepository _rentalStatusRepository;
        private PaymentStatusRepository _rentalPaymentRepository;


        // Entidad de contrato de alquiler y detalles relacionados
        private RentalContract? _rentalContractEntity = null;
        public RentalContractRecord RentalContractRecord { get; set; }
        public int RentalContractId { get; private set; }
        public List<Asset> AllAssets { get; set; }



        // Fechas del contrato
        private DateTime? _startDate;
        private DateTime? _endDate;
        private DateTime? _returnDate;
        private string _contratoId;
        private List<DateTime> _fechasCobro;



        // Propiedades para enlazar al UI
        private int _selectedRentalStatusId;
        private int _selectedRentalPeriodId;
        private RentalStatus _selectedRentalStatus;
        public ObservableCollection<RentalPeriod> RentalPeriods { get; set; }
        public ObservableCollection<PaymentStatus> PaymentStatuses { get; set; }
        private ObservableCollection<RentalStatus> _rentalStatuses;
        private ObservableCollection<RentalContractAssetRecord> _rentalContractAssetRecords;
        public ObservableCollection<RentalContractAsset> RentalContractAssets { get; set; }
        private string _selectedAssetName;
        private ObservableCollection<string> _filteredSuggestions;
        private string _searchText;
        private List<string> _assetNames;
        private bool _isPopupOpen;
        private Visibility _fechaCobroVisibility = Visibility.Collapsed;
        private Visibility _cobroVisibility = Visibility.Collapsed;
        private Visibility _estatusCobroVisibility = Visibility.Collapsed;
        public int ContadorContrato { get; set; } = 1;




        // Constructor cuando se edita un contrato existente
        public CreateEditRentalContractVM(int rentalContractId)
        {
            RentalContractId = rentalContractId;
            _rentalContractEntity = new RentalContract();
            _repository = new RentalContractRepository();
            RentalContractRecord = new RentalContractRecord();
            EditData(rentalContractId);
        }



        // Constructor por defecto para crear un nuevo contrato
        public CreateEditRentalContractVM()
        {
            RentalContractAssets = new ObservableCollection<RentalContractAsset>(); 
            AllAssets = new List<Asset>();
            FilteredSuggestions = new ObservableCollection<string>();
            LoadAssetsFromDatabase();
            RentalContractAssets = new ObservableCollection<RentalContractAsset>();
            _rentalContractEntity = new RentalContract();
            _repository = new RentalContractRepository();
            var rentalStatusRepository = new RentalStatusRepository();
            rentalStatusRepository.SeedRentalStatuses();
            _rentalPeriodRepository = new RentalPeriodRepository();
            var rentalPeriodRepository = new RentalPeriodRepository();
            rentalPeriodRepository.Database.EnsureCreated(); 
            RentalPeriods = new ObservableCollection<RentalPeriod>(
                _rentalPeriodRepository.GetAllRentalPeriods()
            );
            _rentalStatusRepository = new RentalStatusRepository();
            LoadRentalStatuses(); 
            seedRentalPeriods(); 
            LoadAllAssets();
            RentalContractRecord = new RentalContractRecord();
            InitializePaymentStatusRepository();
        }
        private void InitializePaymentStatusRepository()
        {
            // Crear una instancia del repositorio
            _rentalPaymentRepository = new PaymentStatusRepository();

            // Aplica las migraciones (si tienes migraciones)
            _rentalPaymentRepository.Database.Migrate();  // Esto es mejor que EnsureCreated()

            // Cargar datos de ejemplo (si no existen)
            _rentalPaymentRepository.SeedPaymentStatuses();

            // Inicializa la colección de PaymentStatuses
            PaymentStatuses = new ObservableCollection<PaymentStatus>(_rentalPaymentRepository.GetAllPaymentStatuses());
        }



        // Propiedad para almacenar y notificar el ID del estado de renta seleccionado en la interfaz gráfica
        public int SelectedRentaStatusId
        {
            get { return _selectedRentalStatusId;}
            set
            {
                _selectedRentalStatusId = value;
                OnPropertyChanged(nameof(SelectedRentaStatusId));
            }
        }
        // Comando para restablecer los datos a su estado inicial
        public ICommand ResetCommand
        {
            get
            {
                if (_resetCommand == null)
                {
                    _resetCommand = new RelayCommand(param => ResetData(), null);
                }

                return _resetCommand;
            }
        }
        // Comando para guardar los datos ingresados o modificados
        public ICommand SaveCommand
        {
            get
            {
                if (_saveCommand == null)
                {
                    _saveCommand = new RelayCommand(param => SaveData((object)param), null);
                }

                return _saveCommand;
            }
        }
        // Comando para editar datos específicos basados en un ID proporcionado
        public ICommand EditCommand
        {
            get
            {
                if (_editCommand == null)
                {
                    _editCommand = new RelayCommand(param => EditData((int)param), null);
                }
                return _editCommand;
            }
        }
        // Propiedad para almacenar y notificar la fecha de inicio seleccionada
        public DateTime? StartDate
        {
            get => _startDate;
            set
            {
                if (_startDate != value)
                {
                    _startDate = value;
                    OnPropertyChanged(nameof(StartDate));
                }
            }
        }
        // Propiedad para almacenar y notificar la fecha de finalización seleccionada
        public DateTime? EndDate
        {
            get => _endDate;
            set
            {
                if (_endDate != value)
                {
                    _endDate = value;
                    OnPropertyChanged(nameof(EndDate));
                }
            }
        }
        // Propiedad para almacenar y notificar la fecha de devolución seleccionada
        public DateTime? ReturnDate
        {
            get => _returnDate;
            set
            {
                if (_returnDate != value)
                {
                    _returnDate = value;
                    OnPropertyChanged(nameof(ReturnDate));
                }
            }
        }
        // Propiedad para almacenar y notificar el ID del período de renta seleccionado
        public int SelectedRentalPeriodId
        {
            get => _selectedRentalPeriodId;
            set
            {
                _selectedRentalPeriodId = value;
                OnPropertyChanged(nameof(SelectedRentalPeriodId));
            }
        }
        // Colección observable que contiene los diferentes estados de renta disponibles
        public ObservableCollection<RentalStatus> RentalStatuses
        {
            get { return _rentalStatuses; }
            set
            {
                _rentalStatuses = value;
                OnPropertyChanged(nameof(RentalStatuses));
            }
        }
        // Propiedad para almacenar y notificar el estado de renta actualmente seleccionado
        public RentalStatus SelectedRentalStatus
        {
            get { return _selectedRentalStatus; }
            set
            {
                _selectedRentalStatus = value;
                OnPropertyChanged(nameof(SelectedRentalStatus));
            }
        }
        // Colección observable que almacena los registros de activos asociados a los contratos de renta
        public ObservableCollection<RentalContractAssetRecord> RentalContractAssetRecords
        {
            get => _rentalContractAssetRecords;
            set
            {
                _rentalContractAssetRecords = value;
                OnPropertyChanged(nameof(RentalContractAssetRecords));
            }
        }
        // Colección observable que almacena las sugerencias filtradas basadas en el texto de búsqueda
        public ObservableCollection<string> FilteredSuggestions
        {
            get => _filteredSuggestions;
            set
            {
                _filteredSuggestions = value;
                OnPropertyChanged(nameof(FilteredSuggestions));
            }
        }
        // Propiedad para almacenar y notificar el texto de búsqueda ingresado por el usuario
        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged(nameof(SearchText));
                UpdateSuggestions(); 
            }
        }
        // Lista que almacena los nombres de los activos disponibles
        public List<string> AssetNames
        {
            get => _assetNames;
            set
            {
                _assetNames = value;
                OnPropertyChanged(nameof(AssetNames));
            }
        }
        // Propiedad que indica si el popup (ventana emergente) está abierto o cerrado
        public bool IsPopupOpen
        {
            get => _isPopupOpen;
            set
            {
                _isPopupOpen = value;
                OnPropertyChanged(nameof(IsPopupOpen));
            }
        }
        // Método que actualiza las sugerencias basadas en el texto de búsqueda ingresado
        private void UpdateSuggestions()
        {
            if (string.IsNullOrWhiteSpace(SearchText))
            {
                FilteredSuggestions.Clear();
                IsPopupOpen = false;
                return;
            }

            var lowerText = SearchText.ToLower();
            var filtered = AssetNames.Where(name => name.ToLower().Contains(lowerText)).ToList();

            FilteredSuggestions.Clear();
            foreach (var suggestion in filtered)
            {
                FilteredSuggestions.Add(suggestion);
            }

            IsPopupOpen = FilteredSuggestions.Any(); // Abre el popup si hay sugerencias
        }
        // Método para filtrar las sugerencias basadas en el texto de búsqueda
        public void FilterSuggestions()
        {
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var lowerText = SearchText.ToLower();
                FilteredSuggestions = new ObservableCollection<string>(
                    AssetNames.Where(name => name.ToLower().Contains(lowerText)).ToList()
                );
            }
            else
            {
                FilteredSuggestions.Clear();
            }

            IsPopupOpen = FilteredSuggestions.Any(); 
        }
        // Propiedad para almacenar el nombre del activo seleccionado
        public string SelectedAssetName
        {
            get => _selectedAssetName;
            set
            {
                _selectedAssetName = value;
                OnPropertyChanged(nameof(SelectedAssetName));
            }
        }
        //Propiedad para el identificador del contrato
        public string ContratoId
        {
            get => _contratoId;
            set
            {
                if (_contratoId != value)
                {
                    _contratoId = value;
                    OnPropertyChanged(nameof(ContratoId));
                }
            }
        }
        //Propiedad para las fechas de cobro
        public List<DateTime> FechasCobro
        {
            get => _fechasCobro;
            set
            {
                _fechasCobro = value;
                OnPropertyChanged(nameof(FechasCobro));
            }
        }
        //Propiedad para controlar la visibilidad de la fecha de cobro
        public Visibility FechaCobroVisibility
        {
            get => _fechaCobroVisibility;
            set
            {
                _fechaCobroVisibility = value;
                OnPropertyChanged(nameof(FechaCobroVisibility));
            }
        }
        //Propiedad para controlar la visibilidad de cobro 
        public Visibility CobroVisibility
        {
            get => _cobroVisibility;
            set
            {
                _cobroVisibility = value;
                OnPropertyChanged(nameof(CobroVisibility));
            }
        }
        //Propiedad para controlar la visibilidad del estatus de cobro
        public Visibility EstatusCobroVisibility
        {
            get => _estatusCobroVisibility;
            set
            {
                _estatusCobroVisibility = value;
                OnPropertyChanged(nameof(EstatusCobroVisibility));
            }
        }
 

        //Imput de cobro y de fechas de cobro 
        //Estado de cobro 
        //public void imput_cobro()
        //{
        //    Trace.WriteLine("Entro al imput de cobro.");
        //}
        //public void charges()
        //{
        //    Trace.WriteLine("Entro a la vista de caegos ");
        //}
        // Método para cargar los activos desde la base de datos
        public void LoadAssetsFromDatabase()
        {
            using (var dbContext = new DatabaseRepository())
            {
                // Obtenemos todos los Assets de la base de datos
                var assets = dbContext.Assets.ToList();
                if (assets == null || !assets.Any())
                {
                    Console.WriteLine("No se encontraron Assets en la base de datos.");
                    return;
                }
                // Inicializamos la lista de nombres si es null
                if (AssetNames == null)
                {
                    AssetNames = new List<string>();
                }
                // Limpiamos la lista antes de agregar nuevos valores
                AssetNames.Clear();
                // Llenamos los nombres de los Assets para el autocompletado
                foreach (var asset in assets)
                {
                    if (asset != null)
                    {
                        AssetNames.Add(asset.Name); // Solo cargamos los nombres
                    }
                }
            }
        }


        //public int? SelectedAssetTypeId { get; set; } // Representa el ID del tipo de activo seleccionado
                                                      //public ObservableCollection<Charges> CobrosGenerados { get; set; } = new ObservableCollection<Charges>();
        private ObservableCollection<Charges> _cobrosGenerados;

        public ObservableCollection<Charges> CobrosGenerados
        {
            get { return _cobrosGenerados; }
            set
            {
                _cobrosGenerados = value;
                OnPropertyChanged(nameof(CobrosGenerados));
            }
        }
        // Método para agregar un activo seleccionado a la colección de contratos de alquiler
        public void AddSelectedAsset()
        {
            // Verifica si se ha seleccionado un activo válido (nombre no vacío)
            if (string.IsNullOrWhiteSpace(SelectedAssetName))
            {
                Console.WriteLine("No se ha seleccionado un Asset válido.");
                return;
            }
            using (var dbContext = new DatabaseRepository())
            {
                // Buscar el Asset por nombre ingresado en el TextBox
                var asset = dbContext.Assets
                    .FirstOrDefault(a => EF.Functions.Like(a.Name, SelectedAssetName.Trim()));
                if (asset == null)
                {
                    Console.WriteLine($"El Asset con nombre '{SelectedAssetName}' no existe en la base de datos.");
                    return;
                }
                // Buscar el tipo de activo para obtener el precio
                using (var assetTypeRepository = new AssetTypeRepository())
                {
                    var assetType = assetTypeRepository.Get(asset.AssetTypeId);
                    if (assetType == null)
                    {
                        Console.WriteLine($"El tipo de activo con ID {asset.AssetTypeId} no existe.");
                        return;
                    }
                    // Inicializamos la colección si es null
                    if (RentalContractAssets == null)
                    {
                        RentalContractAssets = new ObservableCollection<RentalContractAsset>();
                    }

                    // Agregar el activo seleccionado a la colección
                    RentalContractAssets.Add(new RentalContractAsset
                    {
                        Asset = asset,
                        Amount = 1, // Valor predeterminado
                        Price = assetType.Price
                    });

                    Console.WriteLine($"Asset '{SelectedAssetName}' agregado correctamente.");
                }
            }
        }




        // Método para cargar todos los activos desde la base de datos
        private void LoadAllAssets()
        {
            using( var context = new DatabaseRepository())
            {
                AllAssets = context.Assets
                    .Include(a => a.AssetType)
                    .ToList();
            }
            OnPropertyChanged(nameof(AllAssets));
        }



        // Método para cargar todos los estatus desde la base de datos
        public void LoadRentalStatuses()
        {
            var rentalStatuses = _rentalStatusRepository.GetAllRentalStatuses();
            RentalStatuses = new ObservableCollection<RentalStatus>(rentalStatuses);
        }




        // Método para cargar todos los periodos de renta desde la base de datos
        public void seedRentalPeriods()
        {
            var rentalPeriods = _rentalPeriodRepository.GetAllRentalPeriods();
            RentalPeriods = new ObservableCollection<RentalPeriod>(rentalPeriods);
        }
       


        //Metodo para resetar la informacion de contrato 
        public void ResetData()
        {
            RentalContractRecord.Id = 0;
            RentalContractRecord.CustomerId = 0;
            RentalContractRecord.RentalDate = DateTime.Now;
            RentalContractRecord.DueDate = DateTime.Now.AddMonths(1);
            RentalContractRecord.ReturnDate = DateTime.Now;
            RentalContractRecord.RentalStatusId = 0;
            RentalContractRecord.RentalPeriodId = 0;
        }



        //Metodo para guardar el contrato de renta
        public void SaveData(Object? param)
        {
            if (RentalContractRecord != null)
            {
                // Actualizando los valores del RentalContractEntity con los datos de RentalContractRecord
                _rentalContractEntity.CustomerId = RentalContractRecord.CustomerId;
                _rentalContractEntity.RentalDate = RentalContractRecord.RentalDate;
                _rentalContractEntity.DueDate = RentalContractRecord.DueDate;
                _rentalContractEntity.ReturnDate = RentalContractRecord.ReturnDate;
                _rentalContractEntity.RentalStatusId = RentalContractRecord.RentalStatusId;
                _rentalContractEntity.RentalPeriodId = RentalContractRecord.RentalPeriodId;
                try
                {
                    if (RentalContractRecord.Id <= 0)
                    {
                        _repository.Add(_rentalContractEntity);
                        _repository.SaveChanges();

                        MessageBox.Show("Nuevo contrato de renta creado correctamente.");
                    }
                    else
                    {
                        _rentalContractEntity.Id = RentalContractRecord.Id;
                        _repository.Update(_rentalContractEntity);
                        MessageBox.Show("Contrato de renta editado correctamente.");
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex);
                    MessageBox.Show("Ocurrió un error durante la creación. " + ex.InnerException);
                }
                finally
                {
                    if (param != null && param.Equals("SaveAndNew"))
                    {
                        var mainViewModel = (Application.Current.MainWindow as MainWindow).DataContext as MainViewModel;

                        if (mainViewModel.ShowCreateEditRentalContractViewCommand.CanExecute(null))
                        {
                            mainViewModel.ShowCreateEditRentalContractViewCommand.Execute(null);
                        }
                    }
                    ResetData();
                }
            }
        }




        //Metodo para editar la informacion del contrato de renta 
        public void EditData(int id)
        {
            var model = _repository.Get(id);
            RentalContractRecord.Id = model.Id;
            RentalContractRecord.CustomerId = model.CustomerId;
            RentalContractRecord.RentalDate = model.RentalDate;
            RentalContractRecord.DueDate = model.DueDate;
            RentalContractRecord.ReturnDate = model.ReturnDate;
            RentalContractRecord.RentalStatusId = model.RentalStatusId;
            RentalContractRecord.RentalPeriodId = model.RentalPeriodId;
        }




        // Método para obtener los clientes desde la base de datos
        public List<(int Id, string Name)> GetClients()
        {
            List<(int Id, string Name)> result = new List<(int Id, string Name)>();
            FbConnection connection = new FbConnection();

            try
            { 
                connection = MicrosipConnection.getInstance().CreateConnection();
                connection.Open();

                string query = "SELECT CLIENT_ID, CLIENT_NAME FROM CLIENTS";

                using (FbCommand command = new FbCommand(query, connection))
                using (FbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add((reader.GetInt32(0), reader.GetString(1)));
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
            return result;
        }     
    }
}


