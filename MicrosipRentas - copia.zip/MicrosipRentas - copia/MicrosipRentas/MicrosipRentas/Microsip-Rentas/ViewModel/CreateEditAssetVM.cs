﻿using FirebirdSql.Data.FirebirdClient;
using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using Microsip_Rentas.View;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;

namespace Microsip_Rentas.ViewModel
{
    /// <summary>
    /// ViewModel para crear y editar activos.
    /// Implementa INotifyPropertyChanged para notificar cambios en las propiedades.
    /// </summary>
    public class CreateEditAssetVM : ViewModelBase, INotifyPropertyChanged
    {
        private ICommand _saveCommand; // Comando para guardar un activo
        private ICommand _resetCommand; // Comando para restablecer los datos
        private ICommand _editCommand; // Comando para editar un activo existente
        private AssetRepository _repository; // Repositorio para gestionar operaciones de activos
        private AssetStatusRepository _assetStatusRepository; // Repositorio para gestionar estados de activos
        private AssetTypeRepository _assetTypeRepository; // Repositorio para gestionar tipos de activos
        private Asset? _assetEntity = null; // Entidad del activo que se está creando o editando
        private readonly AssetStatusRepository assetStatusRepository;
        public List<AssetStatus> AssetStatuses { get; set; } // Lista de estados de activo

        // Propiedad para almacenar los datos del activo en edición o creación
        public AssetRecord AssetRecord { get; set; }

        // Identificador del activo en edición
        public int AssetId { get; private set; }

        // Propiedad para el estado seleccionado del activo
        private int _selectedAssetStatusId; // Variable privada para el estado seleccionado
        public int SelectedAssetStatusId
        {
            get { return _selectedAssetStatusId; }
            set
            {
                _selectedAssetStatusId = value;
                OnPropertyChanged(nameof(SelectedAssetStatusId)); // Notifica el cambio
            }
        }

        private AssetStatus _selectedAssetStatus; // Variable privada para almacenar el estado seleccionado
        public AssetStatus SelectedAssetStatus
        {
            get { return _selectedAssetStatus; }
            set
            {
                _selectedAssetStatus = value;
                OnPropertyChanged(nameof(SelectedAssetStatus)); // Notifica el cambio
            }
        }

        // Comando para restablecer los datos del activo
        public ICommand ResetCommand
        {
            get
            {
                if (_resetCommand == null)
                {
                    _resetCommand = new RelayCommand(param => ResetData(), null); // Crea un nuevo RelayCommand que llama a ResetData
                }
                return _resetCommand; // Devuelve el comando de restablecimiento
            }
        }

        // Comando para guardar los datos del activo
        public ICommand SaveCommand
        {
            get
            {
                if (_saveCommand == null)
                {
                    _saveCommand = new RelayCommand(param => SaveData(param), null); // Crea un nuevo RelayCommand que llama a SaveData
                }
                return _saveCommand; // Devuelve el comando de guardar
            }
        }

        // Comando para editar los datos de un activo existente
        public ICommand EditCommand
        {
            get
            {
                if (_editCommand == null)
                {
                    _editCommand = new RelayCommand(param => EditData((int)param), null); // Crea un nuevo RelayCommand que llama a EditData
                }
                return _editCommand; // Devuelve el comando de edición
            }
        }

        // Constructor que inicializa el ViewModel con el ID de un activo para edición
        public CreateEditAssetVM(int assetId)
        {
            AssetId = assetId; // Asigna el ID del activo a la propiedad AssetId
            _assetEntity = new Asset(); // Crea una nueva instancia de la entidad Asset
            _repository = new AssetRepository(); // Inicializa el repositorio de activos
            AssetRecord = new AssetRecord(); // Crea un nuevo registro de activo
            _assetTypeRepository = new AssetTypeRepository();
            InitializeAssetStatusRepository(); // Carga los estados de activos
            assetStatusRepository = new AssetStatusRepository();
            EditData(assetId); // Llama a EditData para cargar los datos del activo existente
        }

        // Constructor para crear un nuevo activo
        public CreateEditAssetVM()
        {
            _assetEntity = new Asset(); // Crea una nueva instancia de la entidad Asset
            _repository = new AssetRepository(); // Inicializa el repositorio de activos
            AssetRecord = new AssetRecord(); // Crea un nuevo registro de activo
            _assetTypeRepository = new AssetTypeRepository();
            _assetStatusRepository = new AssetStatusRepository();
            LoadAssetTypes();// Cargar tipos de activos al inicializar
            InitializeAssetStatusRepository(); // Carga los estados de activos
        }

        // Método de inicialización del repositorio de AssetStatus
        private void InitializeAssetStatusRepository()
        {
            _assetStatusRepository = new AssetStatusRepository();

            // Asegurarse de que la base de datos está creada y cargar datos de prueba
            _assetStatusRepository.Database.EnsureCreated();
            _assetStatusRepository.SeedAssetStatuses(); // Asegúrate de que este método esté implementado
            AssetStatuses = new List<AssetStatus>(_assetStatusRepository.GetAllAssetStatuses()); // Cargar los estados de activos en la colección
        }

        // Método para restablecer los datos del activo a sus valores predeterminados
        public void ResetData()
        {
            AssetRecord.Id = 0; // Reinicia el ID del registro
            AssetRecord.Name = string.Empty; // Reinicia el nombre del activo
            AssetRecord.AssetTypeId = 0; // Reinicia el tipo de activo
            SelectedAssetStatusId = 1; // Restablece el estado activo por defecto
        }

        // Método para guardar los datos del activo
        public void SaveData(object? param)
        {
            if (AssetRecord != null)
            {
                // Validación del nombre del activo
                if (string.IsNullOrWhiteSpace(AssetRecord.Name))
                {
                    MessageBox.Show("El nombre del activo no puede estar vacío.");
                    return;
                }

                // Validación del tipo de activo
                var assetType = _assetTypeRepository.Get(AssetRecord.AssetTypeId);
                if (assetType == null)
                {
                    MessageBox.Show("Nuevo activo creado correctamente.");
                    return;
                }

                // Mapea los datos del registro de AssetRecord a la entidad de _assetEntity
                _assetEntity.Name = AssetRecord.Name;
                _assetEntity.AssetTypeId = AssetRecord.AssetTypeId; // Asignar el ID del tipo de activo
                _assetEntity.AssetStatusId = SelectedAssetStatusId; // Asigna el estado seleccionado
                try
                {
                    // Si el ID del activo es 0 o menor, es un nuevo activo
                    if (AssetRecord.Id <= 0)
                    {
                        _repository.Add(_assetEntity); // Agregar nuevo activo
                    }
                    else // Si el ID es mayor a 0, es una edición de activo existente
                    {
                        _assetEntity.Id = AssetRecord.Id;
                        _repository.Update(_assetEntity); // Actualizar activo existente
                    }
                    _repository.SaveChanges(); // Guardar cambios en la base de datos
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error durante la creación: " + ex.Message);
                }
                finally
                {
                    // Si el parámetro es "SaveAndNew", redirige a la vista para crear un nuevo activo
                    if (param != null && param.Equals("SaveAndNew"))
                    {
                        var mainViewModel = (Application.Current.MainWindow as MainWindow)?.DataContext as MainViewModel;
                        mainViewModel?.ShowCreateEditAssetViewCommand.Execute(null);
                    }
                    ResetData(); // Limpiar los datos después de guardar
                }
            }
            else
            {
                MessageBox.Show("No hay datos del activo para guardar.");
            }
        }


        public AssetStatus GetAssetStatusById(int id)
        {
            try
            {
                return _assetStatusRepository.GetAssetStatus(id);
            }
            catch (Exception ex)
            {
                // Manejo de errores, por ejemplo, mostrar el mensaje en la consola o un log
                Console.WriteLine("Error obteniendo el estado de activo: " + ex.Message);
                return null;
            }
        }

        // Método para cargar los datos de un activo existente en la propiedad AssetRecord
        public void EditData(int id)
        {
            var model = _repository.Get(id); // Obtener el modelo del activo desde el repositorio
            if (model != null)
            {
                AssetRecord.Id = model.Id;
                AssetRecord.Name = model.Name;
                AssetRecord.AssetTypeId = model.AssetTypeId; // Asigna el ID del tipo de activo
                SelectedAssetStatusId = model.AssetStatusId; // Asigna el estado del activo editado

                // Llamar a LoadAssetTypes para asegurar que los tipos de activos están cargados antes de asignar el tipo de activo
                LoadAssetTypes();

                // Asigna el tipo de activo seleccionado
                SelectedAssetType = AssetTypes.FirstOrDefault(type => type.Id == model.AssetTypeId);
            }
            else
            {
                MessageBox.Show("Activo no encontrado.");
            }
        }
         
        // Propiedades para manejar tipos de activos
        public ObservableCollection<AssetType> AssetTypes { get; set; } // Colección de tipos de activo
        private AssetType _selectedAssetType; // Variable privada para el tipo de activo seleccionado
        public AssetType SelectedAssetType
        {
            get { return _selectedAssetType; }
            set
            {
                _selectedAssetType = value;
                OnPropertyChanged(nameof(SelectedAssetType)); // Notifica el cambio
            }
        }

        // Método para cargar tipos de activos al inicializar
        public void LoadAssetTypes()
        {
            AssetTypes = new ObservableCollection<AssetType>(_assetTypeRepository.GetAll());
        }

    }
}







