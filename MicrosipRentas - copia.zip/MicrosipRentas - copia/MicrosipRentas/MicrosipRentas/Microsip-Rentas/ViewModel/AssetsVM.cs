﻿using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Linq;
using System.Diagnostics;

namespace Microsip_Rentas.ViewModel
{
    public class AssetsVM : ViewModelBase, INotifyPropertyChanged
    {
        private ICommand _deleteCommand;
        private ICommand _editCommand;
        private ICommand _addCommand;
        private AssetRepository _repository;
        private AssetTypeRepository _assetTypeRepository;

        public ObservableCollection<Asset> AssetRecords { get; set; }
        public ObservableCollection<AssetType> AssetTypes { get; set; }
        public ObservableCollection<AssetStatus> AssetStatuses { get; set; }

        private ObservableCollection<Asset> _assets; // Campo privado
        public ObservableCollection<Asset> Assets // Propiedad pública para los activos
        {
            get => _assets;
            set
            {
                if (_assets != value)
                {
                    _assets = value;
                    OnPropertyChanged(nameof(Assets)); // Notifica el cambio
                }
            }
        }

        public ICommand DeleteCommand => _deleteCommand ??= new RelayCommand(param => Delete((int)param), null);
        public ICommand EditCommand => _editCommand ??= new RelayCommand(param => Edit((Asset)param), null);
        //public ICommand AddCommand => _addCommand ??= new RelayCommand(param => AddAsset((string)param), null);

        private AssetType _selectedAssetType;
        public AssetType SelectedAssetType
        {
            get { return _selectedAssetType; }
            set { SetField(ref _selectedAssetType, value); }
        }

        private AssetStatus _selectedAssetStatus;
        public AssetStatus SelectedAssetStatus
        {
            get { return _selectedAssetStatus; }
            set { SetField(ref _selectedAssetStatus, value); }
        }

        public List<AssetType> GetAllAssetTypes()
        {
            using (var context = new DatabaseRepository())
            {
                return context.AssetTypes.ToList();
            }
        }

        public AssetsVM()
        {
            _repository = new AssetRepository();
            _assetTypeRepository = new AssetTypeRepository();

            AssetRecords = new ObservableCollection<Asset>();
            AssetTypes = new ObservableCollection<AssetType>();
            AssetStatuses = new ObservableCollection<AssetStatus>();
            LoadAssetTypes();    // Carga los tipos de activos
            LoadAssetStatuses(); // Carga los estatus de activos
            LoadAssets();        // Carga los activos
        }

        private void LoadAssetTypes()
        {
            var assetTypesList = _repository.GetAllAssetTypes(); // Obtiene todos los tipos de activos
            AssetTypes = new ObservableCollection<AssetType>(assetTypesList); // Convierte a ObservableCollection
        }

        private void LoadAssetStatuses()
        {
            var assetStatuses = _repository.GetAllAssetStatuses(); // Obtiene los estatus de los activos
            AssetStatuses.Clear();
            foreach (var assetStatus in assetStatuses)
            {
                AssetStatuses.Add(assetStatus); // Agrega los estatus a la colección
            }
        }

        private void LoadAssets()
        {
            using (var context = new DatabaseRepository())
            {
                var assets = context.Assets
                                    .Include(a => a.AssetType) // Incluye el tipo de activo
                                    .Include(a => a.AssetStatus) // Incluye el estatus del activo
                                    .ToList();

                AssetRecords.Clear();
                foreach (var asset in assets)
                {
                    AssetRecords.Add(asset); // Agrega los activos a la colección
                }
            }
        }

        private void Delete(int id)
        {
            Trace.WriteLine("Entró al delete");
            var result = MessageBox.Show("¿Desea eliminar este activo?", "Confirmación", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    // Llama al método Delete en el repositorio
                    _repository.Delete(id);

                    // Actualiza la lista de activos después de la eliminación
                    LoadAssets();

                    MessageBox.Show("Activo eliminado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocurrió un error al eliminar el activo: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }


        private void Edit(Asset asset)
        {
            Trace.WriteLine("Entro a la vista de editar");
            try
            {
                // Llama al método Update en el repositorio
                _repository.Update(asset);

                // Actualiza la lista de activos después de la edición
                LoadAssets();

                MessageBox.Show("Activo actualizado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error al actualizar el activo: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

   

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName)); // Notifica el cambio de propiedad
        }

        // Utiliza SetField para simplificar la asignación y notificación de cambios
        protected bool SetField<T>(ref T field, T value, [System.Runtime.CompilerServices.CallerMemberName] string propertyName = "")
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        public event PropertyChangedEventHandler PropertyChanged; // Evento para la notificación de cambios
    }
}






