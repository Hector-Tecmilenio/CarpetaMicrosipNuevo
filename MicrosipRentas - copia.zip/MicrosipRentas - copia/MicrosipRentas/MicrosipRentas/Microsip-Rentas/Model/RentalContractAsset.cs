﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    [Table("RentalAssets")]
    public class RentalContractAsset
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("Asset")]
        public int AssetId { get; set; }
        public virtual Asset Asset { get; set; }

        public int RentalContractId { get; set; }
        public virtual RentalContract RentalContract { get; set; }

        public decimal Price { get; set; }
        public int Amount { get; set; }

        // Propiedades de acceso a Asset
        public string AssetName => Asset?.Name;
    }
}
