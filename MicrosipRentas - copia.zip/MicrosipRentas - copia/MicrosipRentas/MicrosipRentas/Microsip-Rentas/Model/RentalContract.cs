﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    [Table("RentalContracts")]
    public class RentalContract
    {
        
        [Key]
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public DateTime RentalDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime ReturnDate { get; set; }

        // Relación con RentalStatus
        [ForeignKey("RentalStatusId")]
        public int RentalStatusId { get; set; }
        public RentalStatus RentalStatus { get; set; }  // Propiedad de navegación

        // Relación con RentalPeriod
        [ForeignKey("RentalPeriodId")]
        public int RentalPeriodId { get; set; }
        public RentalPeriod RentalPeriod { get; set; }  // Propiedad de navegación

        public virtual ICollection<RentalContractAsset> RentalAssets { get; set; }

    }
}

