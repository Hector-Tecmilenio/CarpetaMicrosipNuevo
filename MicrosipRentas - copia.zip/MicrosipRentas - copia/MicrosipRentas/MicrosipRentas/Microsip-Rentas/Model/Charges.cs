﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    public class Charges
    {
        public int Id { get; set; } 
        public DateTime Date { get; set; } 
        public decimal Charge { get; set; }

        // Llave foránea al contrato de renta
        public int RentalContractId { get; set; }
        public RentalContract RentalContract { get; set; }

        // Llave foránea al estatus de pago
        public int PaymentStatusId { get; set; }
        public PaymentStatus PaymentStatus { get; set; }
    }
}
