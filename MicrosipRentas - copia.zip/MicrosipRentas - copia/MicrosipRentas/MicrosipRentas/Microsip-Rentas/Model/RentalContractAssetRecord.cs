﻿using Microsip_Rentas.ViewModel;
using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Microsip_Rentas.Model
{
    public class RentalContractAssetRecord : ViewModelBase
    {
        // Variable para el ID del contrato de activo
        private int _id;
        public int Id
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged(nameof(Id));
            }
        }

        // Variable para el ID del Asset (activo)
        private int _assetId;
        public int AssetId
        {
            get { return _assetId; }
            set
            {
                _assetId = value;
                OnPropertyChanged(nameof(AssetId));
            }
        }

        // Propiedad para el objeto Asset relacionado
        private Asset _asset;
        public Asset Asset
        {
            get { return _asset; }
            set
            {
                _asset = value;
                OnPropertyChanged(nameof(Asset));
            }
        }

        // Variable para el ID del contrato de renta
        private int _rentalContractId;
        public int RentalContractId
        {
            get { return _rentalContractId; }
            set
            {
                _rentalContractId = value;
                OnPropertyChanged(nameof(RentalContractId));
            }
        }

        // Propiedad para el objeto RentalContract relacionado
        private RentalContract _rentalContract;
        public RentalContract RentalContract
        {
            get { return _rentalContract; }
            set
            {
                _rentalContract = value;
                OnPropertyChanged(nameof(RentalContract));
            }
        }

        // Variable para el precio del activo en el contrato
        private decimal _price;
        public decimal Price
        {
            get { return _price; }
            set
            {
                _price = value;
                OnPropertyChanged(nameof(Price));
            }
        }

        // Variable para la cantidad de activos en el contrato
        private int _amount;
        public int Amount
        {
            get { return _amount; }
            set
            {
                _amount = value;
                OnPropertyChanged(nameof(Amount));
            }
        }

        // Colección observable para los registros de contratos de activos
        private ObservableCollection<RentalContractAssetRecord> _rentalContractAssetRecords;
        public ObservableCollection<RentalContractAssetRecord> RentalContractAssetRecords
        {
            get { return _rentalContractAssetRecords; }
            set
            {
                _rentalContractAssetRecords = value;
                OnPropertyChanged(nameof(RentalContractAssetRecords));
            }
        }

        // Constructor
        public RentalContractAssetRecord()
        {
            _rentalContractAssetRecords = new ObservableCollection<RentalContractAssetRecord>();
            _rentalContractAssetRecords.CollectionChanged += RentalContractAssetRecords_CollectionChanged;
        }

        // Método para manejar cambios en la colección de registros
        private void RentalContractAssetRecords_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(nameof(RentalContractAssetRecords));
        }
    }
}

