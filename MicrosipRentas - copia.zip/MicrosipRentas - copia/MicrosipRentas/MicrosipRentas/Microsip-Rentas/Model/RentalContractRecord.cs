﻿using Microsip_Rentas.ViewModel;
using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Microsip_Rentas.Model
{
    public class RentalContractRecord : ViewModelBase
    {
        //Variable que se asigna para guardar el id del contrato.
        private int _id;
        public int Id
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged(nameof(Id));
            }
        }
        //Variable que se esta asignando para guardar el nombre de renta.
        private string _RentalName;
        public string RentalName
        {
            get { return _RentalName; }
            set
            {
                _RentalName = value;
                OnPropertyChanged(nameof(RentalName));
            }
        }
        //Variable que se asigna para guardar el CustomerId.
        private int _customerId;
        public int CustomerId
        {
            get { return _customerId; }
            set
            {
                _customerId = value;
                OnPropertyChanged(nameof(CustomerId));
            }
        }
        //Variable que se asigna para guardar el inicio de la renta.
        private DateTime _rentalDate;
        public DateTime RentalDate
        {
            get { return _rentalDate; }
            set
            {
                _rentalDate = value;
                OnPropertyChanged(nameof(RentalDate));
            }
        }
        //Variable que se utiliza para guardar el fin de la renta.
        private DateTime _dueDate;
        public DateTime DueDate
        {
            get { return _dueDate; }
            set
            {
                _dueDate = value;
                OnPropertyChanged(nameof(DueDate));
            }
        }
        //Variable que se asigna para guardar el regreso de la fecha de renta.
        private DateTime _returnDate;
        public DateTime ReturnDate
        {
            get { return _returnDate; }
            set
            {
                _returnDate = value;
                OnPropertyChanged(nameof(ReturnDate));
            }
        }
        //Variable que se asigna para guardar el Status de renta por Id.
        private int _rentalStatusId;
        public int RentalStatusId
        {
            get { return _rentalStatusId; }
            set
            {
                _rentalStatusId = value;
                OnPropertyChanged(nameof(RentalStatusId));
            }
        }
        //Variable que se asigna para guardar el status de renta general.
        private RentalStatus _rentalStatus;
        public RentalStatus RentalStatus
        {
            get { return _rentalStatus; }
            set
            {
                _rentalStatus = value;
                OnPropertyChanged(nameof(RentalStatus));
            }
        }
        //Variable que se asigna para guardar el periodo de renta por Id.
        private int _rentalPeriodId;
        public int RentalPeriodId
        {
            get { return _rentalPeriodId; }
            set
            {
                _rentalPeriodId = value;
                OnPropertyChanged(nameof(RentalPeriodId));
            }
        }
        //Variable que se asigna para guardar el periodo de renta(general).
        private RentalPeriod _rentalPeriod;
        public RentalPeriod RentalPeriod
        {
            get { return _rentalPeriod; }
            set
            {
                _rentalPeriod = value;
                OnPropertyChanged(nameof(RentalPeriod));
            }
        }

        private ObservableCollection<RentalContractRecord> _rentalContractRecords;
        public ObservableCollection<RentalContractRecord> RentalContractRecords
        {
            get { return _rentalContractRecords; }
            set
            {
                _rentalContractRecords = value;
                OnPropertyChanged(nameof(RentalContractRecords));
            }
        }
        //Constructor 
        public RentalContractRecord()
        {
            _rentalContractRecords = new ObservableCollection<RentalContractRecord>();
            _rentalContractRecords.CollectionChanged += RentalContractRecords_CollectionChanged;
        }
        //Metodo para obtener la coleccion de contratos de renta. 
        private void RentalContractRecords_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(nameof(RentalContractRecords));
        }
    }
}

