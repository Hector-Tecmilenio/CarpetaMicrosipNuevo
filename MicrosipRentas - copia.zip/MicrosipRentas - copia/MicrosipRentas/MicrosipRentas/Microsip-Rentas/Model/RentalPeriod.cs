﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    [Table("RentalPeriods")]
    public class RentalPeriod
    {
        public int Id { get; set; }  // ID del estado del alquiler

        public string PeriodName { get; set; }

        // Relación inversa con RentalContract (1:N)
        public ICollection<RentalContract> RentalContracts { get; set; }
    }
}
