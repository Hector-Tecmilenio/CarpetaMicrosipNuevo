﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    public class ArticleAsset
    {
        public int Id { get; set; }
        public string ArticleName { get; set; }

        //Constructor
        

        
        
    }
}
