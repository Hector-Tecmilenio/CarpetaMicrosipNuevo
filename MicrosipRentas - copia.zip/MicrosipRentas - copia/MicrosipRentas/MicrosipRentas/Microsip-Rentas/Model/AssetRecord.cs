﻿using Microsip_Rentas.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    public class AssetRecord : ViewModelBase
    {
        private int _id;
        public int Id
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged("Id");
            }
        }

        private int _assetId; // Campo para almacenar la referencia al activo.
        public int AssetId
        {
            get { return _assetId; }
            set
            {
                _assetId = value;
                OnPropertyChanged("AssetId");
            }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged("Name");
            }
        }

        private int _assetTypeId;
        public int AssetTypeId
        {
            get { return _assetTypeId; }
            set
            {
                _assetTypeId = value;
                OnPropertyChanged("AssetTypeId");
            }
        }

        private AssetType _assetType;
        public AssetType AssetType
        {
            get { return _assetType; }
            set
            {
                _assetType = value;
                OnPropertyChanged("AssetType");
            }
        }

        private int _assetStatusId;
        public int AssetStatusId
        {
            get { return _assetStatusId; }
            set
            {
                _assetStatusId = value;
                OnPropertyChanged("AssetStatusId");
            }
        }

        private AssetStatus _assetStatus;
        public AssetStatus AssetStatus
        {
            get { return _assetStatus; }
            set
            {
                _assetStatus = value;
                OnPropertyChanged("AssetStatus");
            }
        }

        // Constructor para inicializar valores
        public AssetRecord()
        {
            // Inicialización opcional si es necesario
        }
    }
}

