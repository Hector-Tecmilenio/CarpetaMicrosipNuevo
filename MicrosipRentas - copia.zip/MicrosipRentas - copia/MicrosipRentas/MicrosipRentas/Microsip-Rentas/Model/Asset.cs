﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.Model
{
    [Table("Assets")]
    public class Asset
    {
        [Key]

        public int Id { get; set; }
        
        public string Name { get; set; }
        // Foreign Key for AssetType
        public int AssetTypeId { get; set; }
        public AssetType AssetType { get; set; }

        // Foreign Key for AssetStatus
       
        [ForeignKey("AssetStatusId")]
        public int AssetStatusId { get; set; }
        public AssetStatus AssetStatus { get; set; }
        // Relación con RentalContractAsset
        public virtual ICollection<RentalContractAsset> RentalAssets { get; set; }

    }
}
