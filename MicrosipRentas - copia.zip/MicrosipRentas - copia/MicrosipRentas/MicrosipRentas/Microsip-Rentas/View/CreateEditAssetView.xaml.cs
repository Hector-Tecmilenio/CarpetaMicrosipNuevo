﻿using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using Microsip_Rentas.ViewModel;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Microsip_Rentas.View
{
    public partial class CreateEditAssetView : UserControl
    {
        public List<AssetType> AssetTypesList { get; set; }
        public List<AssetStatus> AssetStatusesList { get; set; }
        public CreateEditAssetView()
        {
            InitializeComponent();
            this.DataContext = new CreateEditAssetVM();
            var assetRepository = new AssetRepository();
            AssetStatusesList = assetRepository.GetAllAssetStatuses();
            var assetTypesVM = new AssetsVM();
            AssetTypesList = assetTypesVM.GetAllAssetTypes();
            tipoActivoCombo.ItemsSource = AssetTypesList;
        }

        private void SaveAndCloseButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(folioText.Text) || string.IsNullOrWhiteSpace(nombreText.Text) ||
                tipoActivoCombo.SelectedItem == null || string.IsNullOrWhiteSpace(notasText.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var selectedAssetType = tipoActivoCombo.SelectedItem as AssetType;
            var selectedAssetStatus = estatusActivoCombo.SelectedItem as AssetStatus;
            var newAsset = new Asset
            {
                Name = nombreText.Text,
                AssetTypeId = selectedAssetType?.Id ?? 0,
                AssetStatusId = selectedAssetStatus?.Id ?? 0 
            };
            try
            {
                var assetRepository = new AssetRepository();
                assetRepository.Add(newAsset);
                var mainViewModel = (Application.Current.MainWindow as MainWindow).DataContext as MainViewModel;
                if (mainViewModel?.ShowAssetViewCommand.CanExecute(null) == true)
                {
                    mainViewModel.ShowAssetViewCommand.Execute(null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el activo: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void SaveAndNewButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(folioText.Text) || string.IsNullOrWhiteSpace(nombreText.Text) ||
                tipoActivoCombo.SelectedItem == null || string.IsNullOrWhiteSpace(notasText.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var selectedAssetType = tipoActivoCombo.SelectedItem as AssetType;
            var selectedAssetStatus = estatusActivoCombo.SelectedItem as AssetStatus;
            var newAsset = new Asset
            {
                Name = nombreText.Text,
                AssetTypeId = selectedAssetType.Id, 
                AssetStatusId = selectedAssetStatus.Id 
            };
            var assetRepository = new AssetRepository();
            assetRepository.Add(newAsset);

            MessageBox.Show("Activo creado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
            folioText.Clear();
            nombreText.Clear();
            notasText.Clear();
            tipoActivoCombo.SelectedIndex = -1;
            estatusActivoCombo.SelectedIndex = -1;
        }

    }
}


