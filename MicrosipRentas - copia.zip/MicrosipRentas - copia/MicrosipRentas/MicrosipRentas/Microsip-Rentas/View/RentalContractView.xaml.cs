﻿using Microsip_Rentas.Model;
using Microsip_Rentas.ViewModel;
using System;
using System.Windows;
using System.Windows.Controls;

namespace Microsip_Rentas.View
{
    /// <summary>
    /// Lógica de interacción para RentalContractsView.xaml
    /// </summary>
    public partial class RentalContractView : UserControl
    {
        //Constructor donde se inicializa DataContext 
        public RentalContractView()
        {
            InitializeComponent();

            // Asignar el DataContext
            RentalContractVM vm = new RentalContractVM();
            DataContext = vm;
        }
        //Metodo para realizar filtrado por su id. 
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            this.Opacity = 0.3;
            FilterAsset window = new FilterAsset();
            window.ShowDialog();
            this.Opacity = 1;
        }
        //Creacion de  un nuevo Contrato 
        private void NewRentalContract_Click(object sender, RoutedEventArgs e)
        {
            var mainViewModel = (Application.Current.MainWindow as MainWindow).DataContext as MainViewModel;

            if (mainViewModel.ShowCreateEditRentalContractViewCommand.CanExecute(null))
            {
                mainViewModel.ShowCreateEditRentalContractViewCommand.Execute(null);
            }
        }
        //Metodo para editar el contrato quuue desee
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var mainViewModel = (Application.Current.MainWindow as MainWindow).DataContext as MainViewModel;
            var button = sender as Button;
            var rentalContractId = button?.CommandParameter as int?;

            if (mainViewModel.ShowCreateEditRentalContractViewCommand.CanExecute(rentalContractId))
            {
                mainViewModel.ShowCreateEditRentalContractViewCommand.Execute(rentalContractId);
            }
        }
        //Metodo para eliminar un contrato de Delete
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
           //
        }
        //
        private void NewButton_Click(object sender, RoutedEventArgs e)
        {
            var mainViewModel = (Application.Current.MainWindow as MainWindow)?.DataContext as MainViewModel;

            if (mainViewModel?.ShowCreateEditRentalContractViewCommand != null &&
                mainViewModel.ShowCreateEditRentalContractViewCommand.CanExecute(null))
            {
                mainViewModel.ShowCreateEditRentalContractViewCommand.Execute(null);
            }
        }
        //Metodo para generar prefacturas 
        private void GenerationPreinvoiceButton_Click(object sender, RoutedEventArgs e)
        {
            // Lógica para generar la pre-factura
            // Agrega aquí el código para manejar la generación de la pre-factura
        }
        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {
            // Lógica para manejar la acción al hacer clic en el botón "Ver"
            // Agrega aquí el código correspondiente
        }

    }
}

