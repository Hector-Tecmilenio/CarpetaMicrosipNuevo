﻿using Microsip_Rentas.DataAccess;
using Microsip_Rentas.Model;
using Microsip_Rentas.ViewModel;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Microsip_Rentas.View
{
    /// <summary>
    /// Lógica de interacción para CreateEditRentalContractView.xaml
    /// </summary>
    public partial class CreateEditRentalContractView : UserControl
    {


        //Propiedades para enlazar al UI
        private RentalPeriodRepository _rentalPeriodRepository;
        public List<RentalPeriod> RentalPeriods { get; set; }
        public CreateEditRentalContractVM _viewModel;
        public ObservableCollection<RentalContractAsset> RentalContractAssets { get; set; }
        public string SelectedAssetName { get; set; }
        public ObservableCollection<string> AssetNames { get; set; } = new ObservableCollection<string>();


        //Constructor 
        public CreateEditRentalContractView()
        {
            InitializeComponent();
            RentalContractAssets = new ObservableCollection<RentalContractAsset>();
            _viewModel = new CreateEditRentalContractVM();
            DataContext = _viewModel;

            AssetNames = new ObservableCollection<string>();
            _rentalPeriodRepository = new RentalPeriodRepository();
            _rentalPeriodRepository.Database.EnsureCreated();
            _rentalPeriodRepository.SeedRentalPeriods();
            Trace.WriteLine("Se abrió la vista de creación/edición de contratos de renta.");
        }




        //Agregar un activo seleccionado al contrato de alquiler
        private void AgregarAtributoButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _viewModel.AddSelectedAsset();
                _viewModel.SelectedAssetName = string.Empty;  
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocurrió un error: {ex.Message}");
            }
        }




        //Guardar el contrato de renta y cerrar la vista
        private void SaveAndCloseButton_Click(object sender, RoutedEventArgs e)
        {
            //TODO: Guardar el contrato de renta y cerrar la vista.

            var mainViewModel = (Application.Current.MainWindow as MainWindow).DataContext as MainViewModel;

            if (mainViewModel.ShowRentalContractViewCommand.CanExecute(null))
            {
                mainViewModel.ShowRentalContractViewCommand.Execute(null);
            }
        }




        //Guardar el contrato de renta y preparar para uno nuevo
        private void SaveAndNewButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Incluir el codigo para guardar.

        }


        private List<RentalContract> GetUpdatedRentalContracts()
        {
            using (var context = new DatabaseRepository())
            {
                return context.RentalContracts
                    .ToList();  // Obtén todos los contratos actualizados
            }
        }


        //Copiar la información necesaria para su uso posterior
        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Incluir la funcion para Copiar la informacion necesaria.

        }




        //Cancelar la acción y revertir cambios
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Incluir el codigo para cancelar el boton.

        }




        //Copiar y cancelar la acción actual
        private void CopyAndCancelButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Incluir para Copiar y cancelar.

        }



        private void SaveCobrosToDatabase(ObservableCollection<Charges> cobrosGenerados)
        {
            using (var context = new DatabaseRepository()) // Asegúrate de usar el contexto adecuado
            {
                foreach (var cobro in cobrosGenerados)
                {
                    // Aquí se guarda cada cobro en la base de datos
                    context.charges.Add(cobro);
                }

                // Guardar los cambios en la base de datos
                context.SaveChanges();
            }
        }

        //Generar las fechas necesarias para el contrato
        private void GenerarFechasButton_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as CreateEditRentalContractVM;

            if (viewModel == null)
                return;

            // Asegurarse de que CobrosGenerados esté inicializado
            if (viewModel.CobrosGenerados == null)
            {
                viewModel.CobrosGenerados = new ObservableCollection<Charges>();
            }

            if (viewModel.StartDate == null || viewModel.EndDate == null)
            {
                MessageBox.Show("Debes ingresar una fecha de inicio y fin antes de generar las fechas de cobro.");
                return;
            }

            // Verificar si hay activos seleccionados en la tabla intermedia
            if (viewModel.RentalContractAssets == null || !viewModel.RentalContractAssets.Any())
            {
                MessageBox.Show("Debes seleccionar al menos un activo antes de generar los cobros.");
                return;
            }

            // Obtener el periodo de renta seleccionado
            var rentalPeriod = viewModel.SelectedRentalPeriodId; // 1 = Diario, 2 = Semanal, 3 = Mensual

            // Variables necesarias
            DateTime startDate = viewModel.StartDate.Value;
            DateTime endDate = viewModel.EndDate.Value;

            // Limpiar cobros existentes antes de generar nuevos
            viewModel.CobrosGenerados.Clear();

            using (var context = new DatabaseRepository()) // Asegúrate de usar el contexto adecuado
            {
                foreach (var rentalContractAsset in viewModel.RentalContractAssets)
                {
                    // Generar fechas dependiendo del periodo de renta
                    var fechasCobro = new List<DateTime>();

                    if (rentalPeriod == 1) // Diario
                    {
                        for (var date = startDate; date <= endDate; date = date.AddDays(1))
                        {
                            fechasCobro.Add(date);
                        }
                    }
                    else if (rentalPeriod == 2) // Semanal
                    {
                        for (var date = startDate; date <= endDate; date = date.AddDays(7))
                        {
                            fechasCobro.Add(date);
                        }
                    }
                    else if (rentalPeriod == 3) // Mensual
                    {
                        var currentDate = startDate;

                        while (currentDate <= endDate)
                        {
                            fechasCobro.Add(currentDate);

                            currentDate = currentDate.AddMonths(1);

                            if (currentDate.Day != startDate.Day)
                            {
                                currentDate = new DateTime(currentDate.Year, currentDate.Month, 1).AddMonths(1).AddDays(-1);
                            }
                        }
                    }

                    // Crear objetos RentalCharge con precio del activo y estado "Pendiente"
                    foreach (var fecha in fechasCobro)
                    {
                        var cobro = new Charges
                        {
                            Date = fecha,
                            Charge = rentalContractAsset.Price * rentalContractAsset.Amount,
                            RentalContractId = viewModel.RentalContractId, // Asignar el ID del contrato de renta
                            //RentalContractAssetId = rentalContractAsset.Id, // Asignar el ID del activo relacionado
                        };

                        // Reutilizar la instancia de PaymentStatus si ya está rastreada en el contexto
                        var paymentStatus = context.PaymentStatuses.Find(1); // Buscar por el ID del estado de pago
                        if (paymentStatus != null)
                        {
                            cobro.PaymentStatus = paymentStatus; // Asignar el estado encontrado
                        }
                        else
                        {
                            // Si no existe, creamos una nueva instancia
                            cobro.PaymentStatus = new PaymentStatus { Id = 1, Description = "Pendiente" };
                        }

                        viewModel.CobrosGenerados.Add(cobro); // Agregar a la colección
                    }
                }

                // Guardar los cobros generados en la base de datos
                context.SaveChanges();
            }

            // Mensaje de éxito
            MessageBox.Show("Las fechas de cobro han sido generadas y guardadas correctamente.");
        }










        //Manejar la selección de sugerencia de autocompletado
        private void OnSuggestionClicked(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBlock textBlock)
            {
                var viewModel = DataContext as CreateEditRentalContractVM;
                if (viewModel != null)
                {
                    viewModel.SearchText = textBlock.Text; // Actualiza el texto en el TextBox
                    viewModel.SelectedAssetName = textBlock.Text; // Guarda el nombre del asset seleccionado
                    viewModel.IsPopupOpen = false; // Cierra el Popup
                }
            }
        }




        //Manejar la selección automática al presionar Enter en el cuadro de texto
        private void OnTextBoxKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                var viewModel = DataContext as CreateEditRentalContractVM;
                if (viewModel != null && viewModel.FilteredSuggestions.Any())
                {
                    // Selecciona el primer resultado si presiona Enter
                    viewModel.SelectedAssetName = viewModel.FilteredSuggestions.First();
                    viewModel.SearchText = viewModel.SelectedAssetName;
                    viewModel.IsPopupOpen = false; // Cierra el popup
                }
            }
        }




        //Metodo para el KeyUp para filtrar los activos disponibles 
        private void OnTextBoxKeyUp(object sender, KeyEventArgs e)
        {
            if (sender is TextBox textBox)
            {
                var viewModel = DataContext as CreateEditRentalContractVM;
                if (viewModel != null)
                {
                    viewModel.SearchText = textBox.Text; 
                    viewModel.FilterSuggestions(); 
                }
            }
        }



        //Generar un nuevo Id para asignarlo a un contrato de renta
        private void GenerarContratoid_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as CreateEditRentalContractVM;
            if (viewModel == null) return;
            var contratoId = $"{viewModel.ContadorContrato}"; 
            viewModel.ContratoId = contratoId;
            viewModel.ContadorContrato++;  
            viewModel.FechaCobroVisibility = Visibility.Visible;
            viewModel.CobroVisibility = Visibility.Visible;
            viewModel.EstatusCobroVisibility = Visibility.Visible;
            MessageBox.Show($"ContratoId generado: {contratoId}",
                            "Contrato Generado",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
        }

    }
}

