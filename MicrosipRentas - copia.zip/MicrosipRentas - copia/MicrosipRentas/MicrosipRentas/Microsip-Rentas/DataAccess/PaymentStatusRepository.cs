﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;

namespace Microsip_Rentas.DataAccess
{
    public class PaymentStatusRepository: DbContext
    {
        public DbSet<PaymentStatus> PaymentStatuses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        // Obtener un PaymentStatus por ID
        public PaymentStatus GetPaymentStatus(int id)
        {
            return this.PaymentStatuses.Find(id);
        }

        // Método para obtener un PaymentStatus por ID (alternativa usando LINQ)
        public PaymentStatus GetPaymentStatusById(int id)
        {
            return this.PaymentStatuses.FirstOrDefault(s => s.Id == id);
        }

        // Obtener todos los PaymentStatuses
        public List<PaymentStatus> GetAllPaymentStatuses()
        {
            return this.PaymentStatuses.ToList();
        }

        // Crear un nuevo PaymentStatus
        public void CreatePaymentStatus(PaymentStatus paymentStatus)
        {
            if (paymentStatus != null)
            {
                this.PaymentStatuses.Add(paymentStatus);
                this.SaveChanges();
            }
        }

        // Actualizar un PaymentStatus existente
        public void UpdatePaymentStatus(PaymentStatus paymentStatus)
        {
            var paymentStatusFind = this.GetPaymentStatus(paymentStatus.Id);
            if (paymentStatusFind != null)
            {
                paymentStatusFind.Description = paymentStatus.Description;
                this.SaveChanges();
            }
        }

        // Eliminar un PaymentStatus por ID
        public void DeletePaymentStatus(int id)
        {
            var paymentStatusObj = this.PaymentStatuses.Find(id);
            if (paymentStatusObj != null)
            {
                this.PaymentStatuses.Remove(paymentStatusObj);
                this.SaveChanges();
            }
        }

        // Método para cargar los estatus iniciales de PaymentStatus
        public void SeedPaymentStatuses()
        {
            if (!this.PaymentStatuses.Any())
            {
                var statuses = new List<PaymentStatus>
                {
                    new PaymentStatus {Description = "Pagado"},
                    new PaymentStatus { Description = "Pendiente" },
                    new PaymentStatus { Description = "Cancelado" }
                };
                this.PaymentStatuses.AddRange(statuses);
                SaveChanges();  // Guarda los cambios en la base de datos
            }
        }


    }
}
