﻿using Microsip_Rentas.Model;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Microsip_Rentas.DataAccess
{
    public class RentalContractRepository : DbContext
    {
        // Conexión a la base de datos
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        //Asignacion de tabla para RentalContract.
        public DbSet<RentalContract> RentalContracts { get; set; }

        //Metodo para obtener un objeto de RentalContract por su ID
        public RentalContract Get(int id)
        {
            Trace.WriteLine("Buscando RentalContract con ID: " + id);
            return this.RentalContracts
                       .Include(rc => rc.RentalStatus)
                       .Include(rc => rc.RentalPeriod)
                       .AsNoTracking()
                       .FirstOrDefault(rc => rc.Id == id);
        }

        // Obtiene todos los objetos de la tabla
        public List<RentalContract> GetAll()
        {
            var allRentalContracts = this.RentalContracts
                                         .Include(rc => rc.RentalStatus)
                                         .Include(rc => rc.RentalPeriod)
                                         .AsNoTracking()
                                         .ToList();

            foreach (var contract in allRentalContracts)
            {
                Trace.WriteLine($"RentalContract en base de datos - ID: {contract.Id}, ClienteID: {contract.CustomerId}, Fecha de Renta: {contract.RentalDate}");
            }
            return allRentalContracts;
        }

        //Metodo para crear un nuevo contrato.
        public void Create(RentalContract rentalContract)
        {
            if (rentalContract != null)
            {
                this.RentalContracts.Add(rentalContract);
                this.SaveChanges();
                Trace.WriteLine("RentalContract creado - ID: " + rentalContract.Id);
            }
        }

        //Metodo para actualizar un contrcato.
        public void Update(RentalContract rentalContract)
        {
            var contractToUpdate = this.Get(rentalContract.Id);
            if (contractToUpdate != null)
            {
                contractToUpdate.CustomerId = rentalContract.CustomerId;
                contractToUpdate.RentalDate = rentalContract.RentalDate;
                contractToUpdate.DueDate = rentalContract.DueDate;
                contractToUpdate.ReturnDate = rentalContract.ReturnDate;
                contractToUpdate.RentalStatusId = rentalContract.RentalStatusId;
                contractToUpdate.RentalPeriodId = rentalContract.RentalPeriodId;
                this.SaveChanges();
                Trace.WriteLine("RentalContract actualizado - ID: " + contractToUpdate.Id);
            }
        }
        private readonly DbContext _context;
        //Metodo para elimina un contrato.
        public void Delete(int id)
        {
            var contractToDelete = this.Get(id);
            if (contractToDelete != null)
            {
                this.RentalContracts.Remove(contractToDelete);
                this.SaveChanges();
                Trace.WriteLine("RentalContract eliminado - ID: " + id);
            }
        }
        // Método para agregar RentalContractAsset
        public void AddRentalContractAsset(RentalContractAsset rentalContractAsset)
        {
            // Asegúrate de que el objeto está correctamente agregado al contexto
            _context.Set<RentalContractAsset>().Add(rentalContractAsset);
        }

        // Guardar los cambios en la base de datos
        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}





