﻿using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsip_Rentas.DataAccess
{
    internal class DatabaseRepository : DbContext
    {

        // Configuracion de la conexión a la base de datos.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        //Definimos una tabla para Asset en la database.
        public DbSet<Asset> Assets { get; set; }
        //Definimos una tabla para AssetType en la database.
        public DbSet<AssetType> AssetTypes { get; set; }
        //Definimos una tabla para AssetStatus en la database.
        public DbSet<AssetStatus> AssetStatuses { get; set; }
        //Definimos una tabla para RentalContracts en la database.
        public DbSet<RentalContract> RentalContracts { get; set; }
        //Definimos una tabla para RentalStatuses en la database.
        public DbSet<RentalStatus> RentalStatuses { get; set; }
        //Definimos una tabla para RentalPeriods en la database.
        public DbSet<RentalPeriod> RentalPeriods { get; set; }
        //Definimos una tabla para RentalAssets en la database(Tabla imntermedia entre [RentalContracts]-[Assets]).
        public DbSet<RentalContractAsset> RentalAssets { get; set; }
        //definicion para tabla de cargos en la base de datos 
        public DbSet<Charges> charges { get; set; }
        //defincion para tabla de estatus de cobro 
        public DbSet<PaymentStatus> PaymentStatuses { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuración de la relación entre Asset y AssetType
            modelBuilder.Entity<Asset>()
                .HasOne(a => a.AssetType)
                .WithMany() // O si quieres puedes configurar .WithMany(x => x.Assets)
                .HasForeignKey(a => a.AssetTypeId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configuración de la relación entre Asset y AssetStatus
            modelBuilder.Entity<Asset>()
                .HasOne(a => a.AssetStatus)
                .WithMany() // O si quieres puedes configurar .WithMany(x => x.Assets)
                .HasForeignKey(a => a.AssetStatusId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configuracion de la relación entre RentalContract y RentalStatus
            modelBuilder.Entity<RentalContract>()
                .HasOne(rc => rc.RentalStatus)
                .WithMany(rs => rs.RentalContracts)
                .HasForeignKey(rc => rc.RentalStatusId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configuracion de la relación entre RentalContract y RentalPeriod
            modelBuilder.Entity<RentalContract>()
                .HasOne(rc => rc.RentalPeriod)
                .WithMany(rp => rp.RentalContracts)
                .HasForeignKey(rc => rc.RentalPeriodId)
                .OnDelete(DeleteBehavior.Restrict);
            // Configuración para RentalStatus
            modelBuilder.Entity<RentalStatus>()
                .ToTable("RentalStatuses");

            // Configuración para RentalPeriod
            modelBuilder.Entity<RentalPeriod>()
                .ToTable("RentalPeriods");

            // Configurar la tabla de RentalContractAsset a RentalAssets
            modelBuilder.Entity<RentalContractAsset>()
                .ToTable("RentalAssets");  // Nombre de la tabla en la base de datos

            // Relación entre RentalContractAsset y Asset
            modelBuilder.Entity<RentalContractAsset>()
                .HasOne(r => r.Asset)
                .WithMany(a => a.RentalAssets)
                .HasForeignKey(r => r.AssetId)
                .OnDelete(DeleteBehavior.Cascade);

            // Relación entre RentalContractAsset y RentalContract
            modelBuilder.Entity<RentalContractAsset>()
                .HasOne(r => r.RentalContract)
                .WithMany()  // Si no necesitas la referencia inversa, se puede dejar vacío
                .HasForeignKey(r => r.RentalContractId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
