﻿using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Microsip_Rentas.DataAccess
{

    public class RentalContractAssetRepository : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        //Asignacion de tabla para RentalContract.
        public DbSet<RentalContract> RentalAssets { get; set; }
        public void AddRentalContractAsset(RentalContractAsset rentalContractAsset)
        {
            using (var dbContext = new DatabaseRepository())
            {
                dbContext.RentalAssets.Add(rentalContractAsset);
                dbContext.SaveChanges();
            }
        }

        public List<RentalContractAsset> GetAllRentalContractAssets()
        {
            using (var dbContext = new DatabaseRepository())
            {
                return dbContext.RentalAssets
                    .Include(r => r.Asset) // Incluir la relación con Assets
                    .Include(r => r.RentalContract) // Incluir la relación con RentalContract
                    .ToList();
            }
        }

        public List<RentalContractAsset> GetRentalContractAssetsByContractId(int rentalContractId)
        {
            using (var dbContext = new DatabaseRepository())
            {
                return dbContext.RentalAssets
                    .Where(r => r.RentalContractId == rentalContractId)
                    .Include(r => r.Asset) // Incluir la relación con Assets
                    .ToList();
            }
        }

        public void UpdateRentalContractAsset(RentalContractAsset rentalContractAsset)
        {
            using (var dbContext = new DatabaseRepository())
            {
                var existing = dbContext.RentalAssets.Find(rentalContractAsset.Id);
                if (existing != null)
                {
                    existing.AssetId = rentalContractAsset.AssetId;
                    existing.RentalContractId = rentalContractAsset.RentalContractId;
                    existing.Amount = rentalContractAsset.Amount;
                    existing.Price = rentalContractAsset.Price;
                    dbContext.SaveChanges();
                }
            }
        }

        public void DeleteRentalContractAsset(int id)
        {
            using (var dbContext = new DatabaseRepository())
            {
                var rentalContractAsset = dbContext.RentalAssets.Find(id);
                if (rentalContractAsset != null)
                {
                    dbContext.RentalAssets.Remove(rentalContractAsset);
                    dbContext.SaveChanges();
                }
            }
        }
    }
}


