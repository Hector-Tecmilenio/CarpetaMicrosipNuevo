﻿using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Microsip_Rentas.DataAccess
{
    public class AssetRepository : DbContext
    {
        // DbSet para Assets y AssetStatuses
        public DbSet<Asset> Assets { get; set; }
        public DbSet<AssetStatus> AssetStatuses { get; set; }
        public DbSet<AssetType> AssetTypes { get; set; }  // Añadir DbSet para AssetType

        // Configuración de la conexión a la base de datos
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        // Obtener un Asset por su ID
        public Asset Get(int id)
        {
            Trace.WriteLine("Buscando Asset con ID: " + id);
            return this.Assets.Find(id);
        }

        // Obtener todos los Assets
        public List<Asset> GetAll()
        {
            var allAssets = this.Assets.AsNoTracking().ToList();
            foreach (var asset in allAssets)
            {
                Trace.WriteLine("Asset en base de datos - ID: " + asset.Id + ", Nombre: " + asset.Name);
            }
            return allAssets;
        }

        // Crear un nuevo Asset
        public void Create(Asset asset)
        {
            if (asset != null)
            {
                this.Assets.Add(asset);
                this.SaveChanges();
                Trace.WriteLine("Asset creado - ID: " + asset.Id);
            }
        }

        // Actualizar un Asset existente
        public void Update(Asset asset)
        {
            if (this.Assets.Any(a => a.Id == asset.Id))
            {
                this.Entry(asset).State = EntityState.Modified;
                this.SaveChanges();
                Trace.WriteLine("Asset actualizado - ID: " + asset.Id);
            }
        }

        // Eliminar un Asset por su ID
        public void Delete(int id)
        {
            var assetObj = this.Assets.Find(id);
            if (assetObj != null)
            {
                this.Assets.Remove(assetObj);
                this.SaveChanges();
                Trace.WriteLine("Asset eliminado - ID: " + id);
            }
        }

        // Obtener todos los AssetStatuses
        public List<AssetStatus> GetAllAssetStatuses()
        {
            return this.AssetStatuses.AsNoTracking().ToList();
        }

        // Obtener todos los AssetTypes
        public List<AssetType> GetAllAssetTypes()
        {
            return this.AssetTypes.AsNoTracking().ToList();
        }

        // Agregar un Asset directamente
        public void Add(Asset asset)
        {
            this.Assets.Add(asset);
            this.SaveChanges();
        }
    }
}




