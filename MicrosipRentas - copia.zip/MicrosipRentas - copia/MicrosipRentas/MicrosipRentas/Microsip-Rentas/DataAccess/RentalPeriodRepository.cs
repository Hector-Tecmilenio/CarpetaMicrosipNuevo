﻿using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Microsip_Rentas.DataAccess
{
    internal class RentalPeriodRepository : DbContext
    {
        public DbSet<RentalPeriod> RentalPeriods { get; set; }

        // Configuración de la base de datos
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName); // Ruta de la base de datos
        }

        // Método para obtener un RentalPeriod por su ID
        public RentalPeriod GetRentalPeriod(int id)
        {
            return RentalPeriods.FirstOrDefault(rp => rp.Id == id); // Devuelve el RentalPeriod con el ID especificado
        }

        // Método para obtener todos los RentalPeriods
        public IEnumerable<RentalPeriod> GetAllRentalPeriods()
        {
            return RentalPeriods.ToList(); // Obtiene todos los RentalPeriods de la base de datos
        }

        // Crear un nuevo RentalPeriod
        public void CreateRentalPeriod(RentalPeriod rentalPeriod)
        {
            if (rentalPeriod != null)
            {
                RentalPeriods.Add(rentalPeriod); // Agrega el nuevo RentalPeriod
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }

        // Actualizar un RentalPeriod existente
        public void UpdateRentalPeriod(RentalPeriod rentalPeriod)
        {
            var rentalPeriodFind = RentalPeriods.Find(rentalPeriod.Id); // Busca el RentalPeriod por su ID
            if (rentalPeriodFind != null)
            {
                rentalPeriodFind.PeriodName = rentalPeriod.PeriodName; // Actualiza el nombre del periodo
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }

        // Eliminar un RentalPeriod por ID
        public void DeleteRentalPeriod(int id)
        {
            var rentalPeriodObj = RentalPeriods.Find(id); // Busca el RentalPeriod por su ID
            if (rentalPeriodObj != null)
            {
                RentalPeriods.Remove(rentalPeriodObj); // Elimina el RentalPeriod
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }

        // Método para cargar datos de prueba
        public void SeedRentalPeriods()
        {
            if (!RentalPeriods.Any()) // Verifica si la tabla está vacía
            {
                var periods = new List<RentalPeriod>
                {
                    new RentalPeriod { Id = 1, PeriodName = "Días" },
                    new RentalPeriod { Id = 2, PeriodName = "Semanas" },
                    new RentalPeriod { Id = 3, PeriodName = "Meses" }
                };

                RentalPeriods.AddRange(periods); // Agrega los datos de prueba
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }
    }
}




