﻿using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Microsip_Rentas.DataAccess
{
    internal class RentalStatusRepository : DbContext
    {
        public DbSet<RentalStatus> RentalStatuses { get; set; }

        // Configuración de la base de datos
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName); // Ruta de la base de datos
        }

        // Método para obtener un RentalStatus por su ID
        public RentalStatus GetRentalStatus(int id)
        {
            return RentalStatuses.FirstOrDefault(rs => rs.Id == id); // Devuelve el RentalStatus con el ID especificado
        }

        // Método para obtener todos los RentalStatuses
        public IEnumerable<RentalStatus> GetAllRentalStatuses()
        {
            return RentalStatuses.ToList(); // Obtiene todos los RentalStatuses de la base de datos
        }

        // Crear un nuevo RentalStatus
        public void CreateRentalStatus(RentalStatus rentalStatus)
        {
            if (rentalStatus != null)
            {
                RentalStatuses.Add(rentalStatus); // Agrega el nuevo RentalStatus
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }

        // Actualizar un RentalStatus existente
        public void UpdateRentalStatus(RentalStatus rentalStatus)
        {
            var rentalStatusFind = RentalStatuses.Find(rentalStatus.Id); // Busca el RentalStatus por su ID
            if (rentalStatusFind != null)
            {
                rentalStatusFind.RentalName = rentalStatus.RentalName; // Actualiza el nombre del estado
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }

        // Eliminar un RentalStatus por ID
        public void DeleteRentalStatus(int id)
        {
            var rentalStatusObj = RentalStatuses.Find(id); // Busca el RentalStatus por su ID
            if (rentalStatusObj != null)
            {
                RentalStatuses.Remove(rentalStatusObj); // Elimina el RentalStatus
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }

        // Método para cargar datos de prueba
        public void SeedRentalStatuses()
        {
            if (!RentalStatuses.Any()) // Verifica si la tabla está vacía
            {
                var statuses = new List<RentalStatus>
                {
                    new RentalStatus { Id = 1, RentalName = "Activo" },
                    new RentalStatus { Id = 2, RentalName = "Pendiente" },
                    new RentalStatus { Id = 3, RentalName = "Completado" },
                    new RentalStatus { Id = 4, RentalName = "Cancelado" }
                };

                RentalStatuses.AddRange(statuses); // Agrega los datos de prueba
                SaveChanges(); // Guarda los cambios en la base de datos
            }
        }
    }
}


