﻿using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Microsip_Rentas.DataAccess
{
    internal class AssetStatusRepository : DbContext
    {
        public DbSet<AssetStatus> AssetStatuses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        // Obtener un AssetStatus por ID
        public AssetStatus GetAssetStatus(int id)
        {
            return this.AssetStatuses.Find(id);
        }
        // Método para obtener un AssetStatus por ID
        public AssetStatus GetAssetStatusById(int id)
        {
            return this.AssetStatuses.FirstOrDefault(s => s.Id == id);
        }

        // Obtener todos los AssetStatuses
        public List<AssetStatus> GetAllAssetStatuses()
        {
            return this.AssetStatuses.ToList();
        }

        // Crear un nuevo AssetStatus
        public void CreateAssetStatus(AssetStatus assetStatus)
        {
            if (assetStatus != null)
            {
                this.AssetStatuses.Add(assetStatus);
                this.SaveChanges();
            }
        }

        // Actualizar un AssetStatus existente
        public void UpdateAssetStatus(AssetStatus assetStatus)
        {
            var assetStatusFind = this.GetAssetStatus(assetStatus.Id);
            if (assetStatusFind != null)
            {
                assetStatusFind.Name = assetStatus.Name;
                assetStatusFind.Description = assetStatus.Description;
                this.SaveChanges();
            }
        }

        // Eliminar un AssetStatus por ID
        public void DeleteAssetStatus(int id)
        {
            var assetStatusObj = this.AssetStatuses.Find(id);
            if (assetStatusObj != null)
            {
                this.AssetStatuses.Remove(assetStatusObj);
                this.SaveChanges();
            }
        }

        // Método para cargar los estatus 
        public void SeedAssetStatuses()
        {
            if (!AssetStatuses.Any())
            {
                var statuses = new List<AssetStatus>
                {
                    new AssetStatus { Id = 1, Name = "Activo", Description = "El activo está en uso y disponible" },
                    new AssetStatus { Id = 2, Name = "Inactivo", Description = "El activo no está en uso actualmente" },
                    new AssetStatus { Id = 3, Name = "En mantenimiento", Description = "El activo está bajo mantenimiento" }
                };

                AssetStatuses.AddRange(statuses);
                SaveChanges();
            }
        }
    }
}





