﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsip_Rentas.Model;
using Microsoft.EntityFrameworkCore;

namespace Microsip_Rentas.DataAccess
{
    public class ChargeRepository : DbContext
    {
        public DbSet<Charges> charges { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=" + App.databaseName);
        }

        // Obtener un Charge por ID
        public Charges GetCharge(int id)
        {
            return this.charges
                .Include(c => c.RentalContract) // Incluye la relación con RentalContract
                .Include(c => c.PaymentStatus) // Incluye la relación con PaymentStatus
                .FirstOrDefault(c => c.Id == id);
        }

        // Obtener todos los Charges
        public List<Charges> GetAllCharges()
        {
            return this.charges
                .Include(c => c.RentalContract) // Incluye la relación con RentalContract
                .Include(c => c.PaymentStatus) // Incluye la relación con PaymentStatus
                .ToList();
        }

        // Crear un nuevo Charge
        public void CreateCharge(Charges charge)
        {
            if (charge != null)
            {
                this.charges.Add(charge);
                this.SaveChanges();
            }
        }

        // Actualizar un Charge existente
        public void UpdateCharge(Charges charge)
        {
            var existingCharge = this.GetCharge(charge.Id);
            if (existingCharge != null)
            {
                existingCharge.Date = charge.Date;
                existingCharge.Charge = charge.Charge;
                existingCharge.RentalContractId = charge.RentalContractId;
                existingCharge.PaymentStatusId = charge.PaymentStatusId;
                this.SaveChanges();
            }
        }

        // Eliminar un Charge por ID
        public void DeleteCharge(int id)
        {
            var charge = this.charges.Find(id);
            if (charge != null)
            {
                this.charges.Remove(charge);
                this.SaveChanges();
            }
        }

        // Obtener Charges por contrato de renta (RentalContract)
        public List<Charges> GetChargesByRentalContractId(int rentalContractId)
        {
            return this.charges
                .Include(c => c.PaymentStatus)
                .Where(c => c.RentalContractId == rentalContractId)
                .ToList();
        }

        // Obtener Charges por estado de pago (PaymentStatus)
        public List<Charges> GetChargesByPaymentStatusId(int paymentStatusId)
        {
            return this.charges
                .Include(c => c.RentalContract)
                .Where(c => c.PaymentStatusId == paymentStatusId)
                .ToList();
        }

    }
}
